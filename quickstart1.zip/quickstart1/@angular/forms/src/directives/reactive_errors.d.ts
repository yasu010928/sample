export declare class ReactiveErrors {
    static controlParentException(): void;
    static ngModelGroupException(): void;
    static missingFormException(): void;
    static groupParentException(): void;
    static arrayParentException(): void;
    static disabledAttrWarning(): void;
}
