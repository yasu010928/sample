import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;

public class Main {
	public static void main(String[] args)  throws  IOException {
		
		//-----------------------------------------------------------------
		// 現在のパスを取得
		//String current_path = getPath();
		//@@@@@@一時的にパスを指定
		String current_path = "//Users/yasuhiro/Desktop/work_nksol";
		//------------------------------------------------------------------
		
		//------------------------------------------------------------------
		//ファイルをgunzipする
		/* 一時的に作業対象ファイルを指定 */
		//Windows ""
		String input_dir_path = "//Users/yasuhiro/Desktop/work_nksol/";
		readFolder(input_dir_path);
		//------------------------------------------------------------------
		// tarファイルを解凍
		String output_path = "//Users/yasuhiro/Desktop/work_nksol";
		decompressTar(output_path);
		//------------------------------------------------------------------
		
		//------------------------------------------------------------------
		//作業用のディレクトリ作成
		mkdir(current_path);
		//------------------------------------------------------------------
		
		//------------------------------------------------------------------
		// ファイルを作業ディレクトリに移動する
		moveFile(input_dir_path);
		//------------------------------------------------------------------
	
		//------------------------------------------------------------------
		// cluent_output.log merge
		String client_log_path = "//Users/yasuhiro/Desktop/work_nksol/01.クライアント/";
		String clinet_merge_file = "//Users/yasuhiro/Desktop/work_nksol/01.クライアント/20190406_ALL_logger_client_output.log";
		fileMerge(client_log_path,clinet_merge_file);
		//------------------------------------------------------------------
		
		
		//------------------------------------------------------------------
		// gzip logger_output
		String logger_output_path = "//Users/yasuhiro/Desktop/work_nksol/02.logger_output";
		compressGzip(logger_output_path);
		
		//------------------------------------------------------------------
		
		//------------------------------------------------------------------
		// logger_err.log merge
		String logger_err_path = "//Users/yasuhiro/Desktop/work_nksol/03.logger_err";
		String logger_err_merge_file = "//Users/yasuhiro/Desktop/work_nksol/03.logger_err/20190406_ALL_logger_err.log";
		fileMerge(logger_err_path, logger_err_merge_file);
		//------------------------------------------------------------------
		
		//------------------------------------------------------------------
		// zip access_log
		//------------------------------------------------------------------
		String access_log_path = "//Users/yasuhiro/Desktop/work_nksol/05.access_log/";
		createZip(access_log_path);
		
	}
	
	public static void createZip(String input_dir_path) {
		File file = new File(input_dir_path);
		File[] files = file.listFiles();
		ZipOutputStream zos = null;
		try {
			createZip(files);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(zos);
		}
	}
	
	
	public static void createZip(File[] files) throws IOException {
	    byte[] buf = new byte[1024];
	    InputStream is = null;
		ZipOutputStream zos = null;
	    try {
	        for (File file : files) {
				zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(new File(file.getPath() + ".zip"))));
	            ZipEntry entry = new ZipEntry(file.getName());
	            zos.putNextEntry(entry);
	            is = new BufferedInputStream(new FileInputStream(file));
	            int len = 0;
	            while ((len = is.read(buf)) != -1) {
	                zos.write(buf, 0, len);
	            }
	        }
	    } finally {
	        IOUtils.closeQuietly(is);
	    }
	}
	
	
	/**
	 * ディレクトリ圧縮のための再帰処理
	 *
	 * @param outZip ZipOutputStream
	 * @param targetFile File 圧縮したいファイル
	 * @param parentFilepath String
	 */
//	private static void recursiveArchive(String file_dir) {
//		ByteArrayOutputStream zipBAOS = new ByteArrayOutputStream();
//		ZipArchiveOutputStream outZip = new ZipArchiveOutputStream(zipBAOS);
//        File targetFile = new File(file_dir);
//		if ( targetFile.isDirectory() ) {
//	        File[] files = targetFile.listFiles();
//	        for (File file : files) {
//	            if ( file.isDirectory() ) {
//	                continue;
//	            } else {
//	                String entryName = file.getName();
//	                System.out.println(file.getName());
//	                // 圧縮処理
//	                archive(outZip, file, entryName);
//	            }
//	        }
//	    }
//	}

	/**
	 * 圧縮処理
	 * @param outZip ZipOutputStream
	 * @param targetFile 圧縮したいファイル
	 * @param entryName 保存ファイル名
	 * @return
	 */
//	public static void archive(ZipArchiveOutputStream outZip, File targetFile, String entryName) {
//
//	    // 圧縮レベル設定
//	    outZip.setLevel(5);
//
//	    try {
//	    	System.out.println("圧縮処理開始");
//	        // ZIPエントリ作成
//	        outZip.putArchiveEntry(new ZipArchiveEntry(entryName));
//	        // 圧縮ファイル読み込みストリーム取得
//	        BufferedInputStream in = new BufferedInputStream(new FileInputStream(targetFile));
//
//	        // 圧縮ファイルをZIPファイルに出力
//	        int size = 0;
//	        //byte buffer[] = new byte[1024]; // 読み込みバッファ
//	        byte[] bff = new byte[1024];
//	        while ((size = in.read(bff, 0, bff.length)) != -1) {
//	            outZip.write(bff, 0, size);
//	        }
//	        in.close();
//	        outZip.closeArchiveEntry();
//
//	        try {
//	            outZip.flush();             
//	        } catch (Exception e) {
//	        }            
//	        
//	    } catch ( Exception e ) {
//	        // ZIP圧縮失敗
//	    	System.out.println("圧縮失敗");
//	        return;
//	    }
//	   
//	}
		
	public static void compressGzip(String input_dir_path) throws IOException{
		File file = new File(input_dir_path);
		File[] files = file.listFiles();
		byte[] buf = new byte[1024];
		BufferedInputStream in = null;
		GZIPOutputStream out = null;
		int size = 0;
		for ( int i = 0; i < files.length; i ++) {
			in = new BufferedInputStream(new FileInputStream(input_dir_path + "/" + files[i].getName()));	
			out = new GZIPOutputStream(new FileOutputStream(input_dir_path + "/" + files[i].getName() + ".gz"));
			 while ((size = in.read(buf, 0, buf.length)) != -1) {
		            out.write(buf, 0, size);   
			}
			out.flush();
			out.close();
			in.close();
		}
		
	}
	
	private static void fileMerge(String dir_path, String output_path) throws IOException {
		File file = new File(dir_path);
		File[] files = file.listFiles();
		String line = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		if (files == null) {
			return;
		}
		java.util.Arrays.sort(files, new java.util.Comparator<File>() {
			public int compare(File file1, File file2){
			    return file1.getName().compareTo(file2.getName());
			}
		});
		bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output_path)));
		for( int i = 0 ; i < files.length ; i++ ){
			System.out.println(files[i].getName());
			br = new BufferedReader(new InputStreamReader(new FileInputStream(files[i])));
			while ((line = br.readLine()) != null) {
				bw.write(line);
				bw.newLine();
			}
			br.close();
			
		} 
		bw.close();
	}

	private static void moveFile(String dir_path) throws IOException {
		// TODO Auto-generated method stub
		try {
			File file = new File(dir_path);
			File[] files = file.listFiles();
			if (files == null) {
				return;
			}
			for (File target_file : files) {
				System.out.println(target_file.getName());
				if (!target_file.exists()) {
					continue;
				}else if (target_file.isDirectory()) {
					continue;
				}
				Path from = null;
				Path to = null;
				// logger_client_log　move
				if (target_file.getName().contains("logger_client_output.log")) {
			        from = Paths.get(target_file.getPath());
			        to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/01.クライアント/" + target_file.getName());
			        Files.move(from, to);
			    // logger_output.log move
				} else if (target_file.getName().contains("logger_output.log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/02.logger_output/" + target_file.getName());
					Files.move(from, to);
				// logger_err.log move
				} else if (target_file.getName().contains("logger_err.log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/03.logger_err/" + target_file.getName());
					Files.move(from, to);
				// access_log move
				} else if (target_file.getName().contains("access_log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/05.access_log/" + target_file.getName());
					Files.move(from, to);
				// error_log move
				} else if (target_file.getName().contains("error_log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/06.access_err_log/" + target_file.getName());
					Files.move(from, to);
				} else if (target_file.getName().contains("logger_err_ex.log")) {
					System.out.println("logger_err_ex.log" + "の処理");
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/07.logger_err_ex_log/" + target_file.getName());
					Files.move(from, to);
				} else if (target_file.getName().contains("logger_ope_err.log")) {
					from = Paths.get(target_file.getPath());
					to = Paths.get("//Users/yasuhiro/Desktop/work_nksol/08.logger_ope_err_log/" + target_file.getName());
					Files.move(from, to);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}


	/**
	 * ログの種類ごとのディレクトリ作成
	 * 
	 * @param file_path
	 */
	public static void mkdir(String file_path) {
		File client_output_log_dir = new File(file_path + "/01.クライアント");
		File logger_output_dir = new File(file_path + "/02.logger_output");
		File logger_err_dir = new File(file_path + "/03.logger_err");
		File access_log = new File(file_path + "/05.access_log");
		File access_err_log = new File(file_path + "/06.access_err_log");
		File logger_err_ex_log = new File(file_path + "/07.logger_err_ex_log");
		File logger_ope_err_log = new File(file_path + "/08.logger_ope_err_log");
	
		client_output_log_dir.mkdir();
		logger_output_dir.mkdir();
		logger_err_dir.mkdir();
		access_log.mkdir();
		access_err_log.mkdir();
		logger_err_ex_log.mkdir();
		logger_ope_err_log.mkdir();
	}
		
	/**
	 * カレントディレクトリのpath取得
	 *
	 * @return カレントディレクトリのpath
	 */
	private static String getPath() {
		String path = new File(".").getAbsoluteFile().getParent();
        System.out.println(path);
        return path;    
	}
	
	/**
	 * 対象ファイルの解凍
	 * 
	 * @param input
	 * @param output
	 * @throws IOException
	 */
	public static void decompressGzip(File input_file, String output_file) throws IOException {
		/** Fixme  */
		File output = new File(output_file);
		try (GZIPInputStream in = new GZIPInputStream(new FileInputStream(input_file))){
			try (FileOutputStream out = new FileOutputStream(output)){
				byte[] buffer = new byte[1024];
	        	int len;
	        	while((len = in.read(buffer)) != -1){
	       			out.write(buffer, 0, len);
	          	}
	       		out.close();
	       		input_file.delete();
	       		
         	} catch (IOException e) {
         		e.printStackTrace();
	        }
	     } catch (Exception e) {
	   		e.printStackTrace();
	   	}
	}
	
	/**
	 * tarアーカイブを解除
	 * 
	 * @param input_file
	 * @throws IOException
	 */
	public static void decompressTar(String output_path)  throws IOException {
		File input_file_path = new File("//Users/yasuhiro/Desktop/work_nksol/");
		File[] files = input_file_path.listFiles();
		if (files == null) {
			return;
		}
		for (File target_file : files) {
			if (!target_file.exists()) {
				continue;
			}else if (target_file.isDirectory()) {
				continue;
			}
			 System.out.println(target_file.getName());

		try( FileInputStream  fis  = new FileInputStream( target_file );
	         TarArchiveInputStream tais = new TarArchiveInputStream( fis ) ) {
	         // エントリーを1つずつファイル・フォルダに復元
	         ArchiveEntry entry   = null;
	         while( ( entry = tais.getNextEntry() ) != null ) {
	        	 // ファイルを作成
	        	 File file = new File( output_path + "/" + entry.getName() );
	        	 // フォルダ・エントリの場合はフォルダを作成して次へ
	        	 if( entry.isDirectory() ){
	        		 continue;
	        	 }
	 
	        	 // ファイル出力する場合
	        	 // フォルダが存在しない場合は事前にフォルダ作成
	        	 if( !file.getParentFile().exists() ){
	        		 file.getParentFile().mkdirs(); 
	        	 }
		         // ファイル出力
		         try(FileOutputStream fos = new FileOutputStream( file ) ;
		        	BufferedOutputStream bos = new BufferedOutputStream( fos ) ){
		        	 // エントリの出力
		        	 	int size = 0;
		        	 	byte[] buf = new byte[ 1024 ];
		        	 	while( tais.read( buf ) > 0 ) {
		        	 		bos.write( buf , 0 , size );
		        	 	}
		         	}
		         }
			}
		}
	}
	
	/**
	 * gzip 解凍
	 * 
	 * @param input_dir_path
	 * @throws IOException
	 */
	public static void readFolder(String input_dir_path) throws IOException {
		File file = new File(input_dir_path);
		File[] files = file.listFiles();
		System.out.println(file.getPath() + file.isFile());
		if (files == null)  {
			return;
		}
		for ( File target_file : files) {
			System.out.println(target_file.getName());
			if (!target_file.exists()) { 
				continue;
			} else if (target_file.isDirectory()) {
				continue;
			} else {
				decompressGzip(target_file,"//Users/yasuhiro/Desktop/work_nksol/" + target_file.getName().replace(".gz", ""));
			}
		}
	}
	
		
}
		
